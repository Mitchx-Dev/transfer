#pragma once

#define HTTP_SERVER "172.105.55.231" //Change this too your SERVER IP
#define HTTP_PORT 80

#define TFTP_SERVER "172.105.55.231" //Change this too your SERVER IP
