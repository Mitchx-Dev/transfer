<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$upload = "upload/";

$conn = mysqli_connect($dbhost, $dbuser, $dbpass);

$dbname = "bee";
mysqli_select_db($conn, $dbname);
?>