<?php
include("config.php");
include('checklogin.php');

if(isset($_POST["submit"])){
	$target_file = $upload.basename($_FILES["newfile"]["name"]);
	if(move_uploaded_file($_FILES["newfile"]["tmp_name"], $target_file)){
	$name = basename($_FILES["newfile"]["name"]);
	$sha256 = hash_file('sha256', $target_file);
	$sql = mysqli_query($conn, "INSERT INTO files (name, sha256, hits) VALUES ('$name', '$sha256', '0')");
	}
}
if(isset($_GET['delete'])){
	$delete_id = $_GET['delete'];
	$check = mysqli_query($conn, "SELECT name FROM files WHERE id='".$delete_id."'");
	$re = mysqli_fetch_assoc($check);
	$sql = mysqli_query($conn, "DELETE FROM files WHERE id='$delete_id';");
	unlink($upload.$re['name']);
	echo '<script>window.location.replace("?");</script>';
	die();
}
if(isset($_GET['file'])){
	$sql = mysqli_query($conn, "SELECT id,name,sha256,hits FROM files WHERE sha256='".$_GET['file']."'");
	$re = mysqli_fetch_assoc($sql);
	$re_file = $upload.$re['name'];
	$re_file_h = hash_file('sha256', $re_file);
	$re_file_s = filesize($re_file);
	echo "<small>";
	echo "ID: ".$re['id'].'<br>';
	echo "Name: ".$re['name'].'<br>';
	echo "Sha256: ".$re['sha256'].'<br>';
	echo "Verify Sha256: ".$re_file_h.'<br>';
	echo "File size: ".$re_file_s.' bytes<br>';
	die();
}
$sql_file = mysqli_query($conn, "SELECT id,name,sha256,hits FROM files ORDER BY id");
?>

<html>
<head>
<title> BL Panel </title>
<style>
@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700');

$base-spacing-unit: 24px;
$half-spacing-unit: $base-spacing-unit / 2;

$color-alpha: #1772FF;
$color-form-highlight: #EEEEEE;

*, *:before, *:after {
	box-sizing:border-box;
}

body {
	padding:$base-spacing-unit;
	font-family:'Source Sans Pro', sans-serif;
	margin:0;
}

h1,h2,h3,h4,h5,h6 {
	margin:0;
}

#image-surround { 
   display: inline-block;
   width: 8%;
}

#image-icon{
	display: inline-block;
	width: 2%;
}

h1 { 
   display: inline-block;
}

#utf a:link {
  color: #000000;
}

#utf a:visited {
  color: #000000;
}

#utf a:hover {
  color: #e60000;
}

#utf a:active {
  color: #000000;
}

.side {
	position: absolute;
	max-width: 5%;
	top: 5%;
	left: 2%;
}

.side button {
  background-color: #000000; 
  border: none;
  color: white;
  width: 50px;
  height: 50px;
  padding: 10px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}

.container {
	max-width: 1000px;
	margin-right:auto;
	margin-left:auto;
	display:flex;
	justify-content:center;
	align-items:center;
	min-height:50%;
}

.table {
	width:100%;
	border:1px solid $color-form-highlight;
}

.table-header {
	display:flex;
	width:100%;
	background:#000;
	padding:($half-spacing-unit * 1.5) 0;
}

.table-row {
	display:flex;
	width:100%;
	padding:($half-spacing-unit * 1.5) 0;

	&:nth-of-type(odd) {
		background:$color-form-highlight;
	}
}

.table-data, .header__item {
	flex: 1 1 20%;
	text-align:center;
}

.header__item {
	text-transform:uppercase;
}

.button {
  background-color: #000000;
  border: none;
  color: white;
  padding: 15px 32px;
  width: 20%;
  margin-right:auto;
  margin-left:auto;
  text-align: center;
  text-decoration: none;
  display: block;
  font-size: 16px;
}


.filter__link {
	color:white;
	text-decoration: none;
	position:relative;
	display:inline-block;
	padding-left:$base-spacing-unit;
	padding-right:$base-spacing-unit;

	&::after {
		content:'';
		position:absolute;
		right:-($half-spacing-unit * 1.5);
		color:white;
		font-size:$half-spacing-unit;
		top: 50%;
		transform: translateY(-50%);
	}

	&.desc::after {
		content: '(desc)';
	}

	&.asc::after {
		content: '(asc)';
	}

}
</style>
<script>
function confirmation(id){
var result = confirm("Want to delete?");
if (result) {
    window.location.href = "?delete="+id;
}
}
function openInNewTab(url) {
  var win = window.open(url, '_blank');
  win.focus();
}
</script>
</head>
<body>
<center>
<img id="image-surround" src="inc/image.png" alt="" />
<h1> BL Panel </h1>
<img id="image-surround" src="inc/image.png" alt="" />
<br><a href="admin.php">(Switch to tasks)</a>
</center>

<div class="side">
<button title="Stats" onclick="openInNewTab('s.php');"> &#9873; </button><br><br>
<button title="Log Out" onclick="location.href='logout.php';"> &#10094; </button><br>
</div>

<div class="container">
	<div class="table">
		<div class="table-header">
			<div class="header__item"><a id="file" class="filter__link">File</a></div>
			<div class="header__item"><a id="sha" class="filter__link filter__link--number">Sha256</a></div>
			<div class="header__item"><a id="hits" class="filter__link filter__link--number">Hits</a></div>
			<div class="header__item"><a id="delete" class="filter__link filter__link--number">Delete</a></div>
		</div>
		<div class="table-content">
		<?php
		while($re = mysqli_fetch_assoc($sql_file)){
			$file_id = $re['id'];
			$file_name = $re['name'];
			$file_hash_f = $re['sha256'];
			$file_hash_o = substr($file_hash_f, 0, 5);
			$file_hash_t = substr($file_hash_f, -5);
			$file_hash = $file_hash_o.'....'.$file_hash_t;
			$file_hits = $re['hits'];
			$href = "javascript:window.open('files.php?file=".$file_hash_f."','mypopuptitle','width=600,height=400')";
			echo '<div class="table-row">';
			echo '<div class="table-data">'.$file_name.'</div>';
			echo '<div class="table-data"><a href="'.$href.'")><font size="3">'.$file_hash.'</font></a></div>';
			echo '<div class="table-data">'.$file_hits.'</div>';
			echo '<div id="utf" class="table-data"><a onclick="confirmation('.$file_id.');" href="#">&#10006;</a></div>';
			echo '</div>';
		}
		?>
		</div>
	</div>
</div>
<br><form method="post" action="" enctype="multipart/form-data"><div style="text-align:center;"> <input type="file" name="newfile" /></div>
<br><input type="submit" class="button" name="submit" value="Add File"/></form>
</body>
</html>
