<?php
function continent($countrycode){
	$NA = array("AI", "AG", "BS", "BB", "BZ", "BM", "CA", "KY", "DM", "DO", "SV", "GD", "GP", "GT", "HT", "HN", "JM", "MQ", "MX", "MS", "NI", "PA", "PR", "BL", "KN", "LC", "SX", "PM", "VC", "TC", "US", "VG", "VI");
	$SA = array("AR", "AW", "BO", "BQ", "BR", "CL", "CO", "CR", "CU", "CW", "EC", "FK", "GF", "GY", "PY", "PE", "SR", "TT", "UY", "VE");
	$EU = array("AL", "AD", "AT", "BY", "BE", "BA", "BG", "HR", "CY", "CZ", "DK", "EE", "FO", "FI", "FR", "GE", "DE", "GI", "GR", "GL", "HU", "IS", "IE", "IM", "IT", "LV", "LI", "LT", "LU", "MK", "MT", "MC", "ME", "NL", "NO", "PL", "PT", "RO", "SM", "RS", "SK", "SI", "ES", "SE", "CH", "GB", "UA");
	$AS = array("AF", "AM", "AZ", "BH", "BD", "BT", "IO", "BN", "KH", "CN", "CX", "CC", "HK", "ID", "IN", "IR", "IQ", "IL", "JP", "JO", "KZ", "KP", "KR", "KW", "KG", "LA", "MO", "MY", "MV", "MN", "MM", "NP", "OM", "PK", "PS", "PH", "QA", "RU", "SA", "SG", "LK", "SY", "TW", "TJ", "TH", "TR", "TM", "AE", "UZ", "VN", "YE");
	$AF = array("DZ", "AO", "BJ", "BW", "BF", "BI", "CM", "CV", "CF", "TD", "KM", "CD", "CI", "DJ", "EG", "GQ", "ER", "ET", "GA", "GM", "GH", "KE", "LB", "LS", "LR", "LY", "MG", "MW", "ML", "MR", "MU", "YT", "MA", "MZ", "NA", "NE", "NG", "RE", "RW", "SH", "ST", "SN", "SC", "SL", "SO", "ZA", "SD", "SZ", "TZ", "TG", "TN", "UG", "ZM", "ZW");
	$OC = array("AS", "AU", "CK", "FJ", "PF", "TF", "GU", "GN", "KI", "MH", "NR", "NC", "NZ", "NU", "NF", "PW", "PG", "PN", "WS", "SB", "TK", "TO", "TV", "VU", "WF");
    switch($countrycode){
		case in_array($countrycode, $NA):
		return "NA";
		break;
		case in_array($countrycode, $SA):
		return "SA";
		break;
		case in_array($countrycode, $EU):
		return "EU";
		break;
		case in_array($countrycode, $AS):
		return "AS";
		break;
		case in_array($countrycode, $AF):
		return "AF";
		break;
		case in_array($countrycode, $OC):
		return "OC";
		break;
		default:
		return "?";
		break;
	}
}

?>