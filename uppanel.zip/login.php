<html>
<head>
<title>Log In </title>
</head>
<body>
<h1> Log In </h1>
<form method="post" action="login.php">
Username: <input type="text" name="login"/><br>
Password: <input type="password" name="password"/><br>
<input type="submit" value="Login"></input><br>
</form>

<?php
include('config.php');
if(isset($_POST['login'])){
$login=$_POST['login']; 
$pass=$_POST['password']; 

// To protect MySQL injection (more detail about MySQL injection)
$login = stripslashes($login);
$pass = stripslashes($pass);
$login = mysqli_real_escape_string($conn, $login);
$pass = mysqli_real_escape_string($conn, $pass);
$sql="SELECT * FROM admin WHERE username='$login' and password='$pass'";
$result=mysqli_query($conn, $sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1){

// Register $myusername, $mypassword and redirect to file "login_success.php"
session_start();
$_SESSION['login'] = $login;
$_SESSION['pass'] = $pass;
header("location:admin.php");
}
else {
echo "Wrong Username or Password";
}
}
?>
